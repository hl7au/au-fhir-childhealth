# {{ page.title }}

Search parameters that have been defined for this implementation guide.

{% include list-simple-searchparameters.xhtml %}
