#### Examples

- [Ears Normal Observation](ncdhc-observation-ears-normal-example.html)