#### Examples

- [Fontanelles Normal Observation](ncdhc-observation-fontanelles-normal-example.html)