This profile is different from [AU Patient](http://build.fhir.org/ig/hl7au/au-fhir-base/StructureDefinition-au-patient.html) in the following way

1. One or more <span style='color:green'>name</span> are made mandatory

