#### Examples

- [Vision Tested Monocularly](ncdhc-observation-vision-tested-monocularly-example.html)