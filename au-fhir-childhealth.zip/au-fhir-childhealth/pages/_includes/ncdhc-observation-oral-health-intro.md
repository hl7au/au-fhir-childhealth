#### Examples

- [Oral Health](ncdhc-observation-oralhealth-normal-example.html)