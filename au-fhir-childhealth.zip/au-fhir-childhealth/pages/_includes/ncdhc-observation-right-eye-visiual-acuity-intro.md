#### Examples

- [Visual acuity - Right Eye](ncdhc-observation-right-eye-visiual-acuity-example.html)