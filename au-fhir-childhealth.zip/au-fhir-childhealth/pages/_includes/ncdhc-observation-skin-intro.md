#### Examples

- [Skin Normal Observation](ncdhc-observation-skin-normal-example.html)
- [Skin Review Observation](ncdhc-observation-skin-review-example.html)