#### Examples

- [Health Check Assessment View 12 Months](ncdhc-hca-12mnths-view-summary.html)