#### Examples

- [Testes Normal Observation](ncdhc-observation-testes-normal-example.html)