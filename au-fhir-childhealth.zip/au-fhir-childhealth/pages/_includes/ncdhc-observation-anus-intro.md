#### Examples

- [Anus Normal Observation](ncdhc-observation-anus-normal-example.html)