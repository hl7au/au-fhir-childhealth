#### Examples

- [Fluoride Varnish](ncdhc-observation-fluoridevarnish-normal-example.html)