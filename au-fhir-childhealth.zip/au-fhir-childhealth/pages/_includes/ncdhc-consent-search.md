Refer to Capability Statement and OAI for more details
