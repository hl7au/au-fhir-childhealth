#### Examples

- [Create Auth Rep](ncdhc-bundle-document-create-authrep.html)