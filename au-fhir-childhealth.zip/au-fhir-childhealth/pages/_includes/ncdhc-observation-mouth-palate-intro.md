#### Examples

- [Mouth Palate Normal](ncdhc-observation-mouthpalate-normal-example.html)