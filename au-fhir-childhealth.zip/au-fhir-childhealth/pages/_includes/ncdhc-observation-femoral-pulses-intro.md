#### Examples

- [Femoral Pulse Normal Observation](ncdhc-observation-femoralpulse-normal-example.html)