#### Examples

- [Visual acuity - Left Eye](ncdhc-observation-left-eye-visiual-acuity-example.html)