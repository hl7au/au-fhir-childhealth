#### Examples

- [Vision Screen](ncdhc-observation-visionscreen-normal-example.html)