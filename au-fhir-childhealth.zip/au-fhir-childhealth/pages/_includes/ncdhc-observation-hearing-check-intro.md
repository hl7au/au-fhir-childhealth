#### Examples

- [Hearing Check](ncdhc-observation-hearingcheck-normal-example.html)