#### Examples

- [Umbilicus Normal Observation](ncdhc-observation-umbilicus-normal-example.html)