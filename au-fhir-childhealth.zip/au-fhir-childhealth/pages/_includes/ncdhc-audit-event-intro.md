#### Examples

- [Consumer Audit View - Create](audit_event_created.html)
- [Consumer Audit View - Read](audit_event_read.html)
- [Consumer Audit View - Update](audit_event_updated.html)
- [Consumer Audit View - Delete](audit_event_deleted.html)
- [System Record Audit Details](audit-event-insert.html)