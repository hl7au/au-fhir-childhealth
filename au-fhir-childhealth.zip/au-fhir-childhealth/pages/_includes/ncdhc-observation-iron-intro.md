#### Examples

- [Iron testing](ncdhc-observation-irontesting-normal-example.html)