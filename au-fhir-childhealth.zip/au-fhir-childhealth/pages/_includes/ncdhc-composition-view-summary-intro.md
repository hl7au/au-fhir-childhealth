

#### Examples

- [Health Check Assessment Summary (NSW)](ncdhc-hca-nsw-summary-sample.html)