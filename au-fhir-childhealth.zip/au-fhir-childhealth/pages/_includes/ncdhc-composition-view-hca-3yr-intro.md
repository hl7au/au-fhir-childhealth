#### Examples

- [Health Check Assessment View 3 Years](ncdhc-hca-3year-view-summary.html)