#### Examples

- [Health Check Assessment View 18 Months](ncdhc-hca-18mnths-view-summary.html)