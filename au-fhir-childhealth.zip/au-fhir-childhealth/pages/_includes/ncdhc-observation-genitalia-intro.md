#### Examples

- [Genitalia Observation](ncdhc-observation-genitalia-normal-example.html)