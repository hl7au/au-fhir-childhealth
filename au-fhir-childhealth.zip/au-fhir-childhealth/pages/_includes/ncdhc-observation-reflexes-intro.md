#### Examples

- [Reflexes Normal Observation](ncdhc-observation-reflexes-normal-example.html)