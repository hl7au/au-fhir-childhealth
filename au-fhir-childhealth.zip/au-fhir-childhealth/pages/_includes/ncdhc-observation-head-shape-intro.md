#### Examples
- [Head Shape Observation](ncdhc-observation-head-shape-normal-example.html)

[Observation]: http://hl7.org/fhir/observation.html
[extensible]: http://hl7.org/fhir/terminologies.html#extensible
[General Guidance Section]: definitions.html
