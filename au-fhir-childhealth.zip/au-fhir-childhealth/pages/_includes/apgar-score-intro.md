**APGAR Score Observation Profile**

APGAR Score Observation profile.
