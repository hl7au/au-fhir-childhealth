#### Examples

- [Abdomen Normal Observation](ncdhc-observation-abdomen-normal-example.html)