# {{ page.title }}

These Profiles have been defined for this implementation guide.

## Patient Profiles
* [NCDHC Baby Patient](StructureDefinition-ncdhc-patient-baby.html) - Demographic details of the Baby Patient.

## Consent Profiles
* [NCDHC Consent Details](StructureDefinition-ncdhc-consent.html) - Consent profile to record access and use of patient record in NCDHC program.

## AuditEvent Profiles
* [NCDHC Audit Details](StructureDefinition-ncdhc-audit-event.html) - AuditEvent profile to record audit details of all operations performed in Data Hub.

## OperationOutcome Profiles
* [NCDHC OperationOutcome](StructureDefinition-ncdhc-operation-outcome.html) - OperationOutcome resource to represent error and informational scenarios in NCDHC.

## Orders and Observation Profiles
* [NCDHC Estimated Gestation](StructureDefinition-ncdhc-observation-estimated-gestation.html) - Observation profile to record gestational age in weeks and days (usually equivalent to length of pregnancy). 


## MedicationStatement Profiles
* [NCDHC Medication Vitamin K](StructureDefinition-ncdhc-medicationstatement-vitamink.html) - MedicationStatement profile to record Vitamin K1 details administered to the newborn at birth

## Encounter Profiles
* [NCDHC Encounter](StructureDefinition-ncdhc-encounter.html) - Encounter profile to record  administrative details (e.g.: date and time of discharge, name of the service or facility the baby was discharged from etc.)

## Questionnaire Profiles
* [NCDHC Questionnaire](StructureDefinition-ncdhc-questionnaire-base.html) - Questionnaire profile 
* [NCDHC QuestionnaireResponse](StructureDefinition-ncdhc-questionnaireresponse-base.html) - QuestionnaireResponse profile 


## Child Digital Health Record Profiles
* [NCDHC Newborn Delivery Health Interaction](StructureDefinition-ncdhc-composition-nbdelivery.html) - Composition profile to represent Newborn Delivery Health Interaction
* [NCDHC Birth Consolidated view](StructureDefinition-ncdhc-composition-view-birth.html) - Consolidated view to represent Birth related details. This view includes summaries from Newborn Delivery, Newborn Discharge, Bloodshot Screening, Hearing Screening and Immunisation.
* [NCDHC Health Check Assessment Health Interaction](StructureDefinition-ncdhc-composition-health-check-assessment.html) - Composition profile to represent Health Check Assessment Health Interaction
* [NCDHC Health Check Schedule view](StructureDefinition-ncdhc-composition-view-schedule.html) - View Health Check Schedule based on Jurisdiction.
* [NCDHC Health Check Summary view](StructureDefinition-ncdhc-composition-view-summary.html) - View Health Check Summary based on Jurisdiction.
* [NCDHC Health Check Assessment 1-4 Weeks view](StructureDefinition-ncdhc-composition-view-hca-14wks.html) - Consolidated view to represent Health Check Assessment performed during 1-4 weeks of Birth.
* [NCDHC Health Check Assessment 6-8 Weeks view](StructureDefinition-ncdhc-composition-view-hca-68wks.html) - Consolidated view to represent Health Check Assessment performed during 6-8 weeks of Birth. 
* [NCDHC Health Check Assessment 6 Months view](StructureDefinition-ncdhc-composition-view-hca-6m.html) - Consolidated view to represent Health Check Assessment performed during 6 months of Birth.
* [NCDHC Health Check Assessment 12 Months view](StructureDefinition-ncdhc-composition-view-hca-12m.html) - Consolidated view to represent Health Check Assessment performed during 12 months of Birth.
* [NCDHC Health Check Assessment 18 Months view](StructureDefinition-ncdhc-composition-view-hca-18m.html) - Consolidated view to represent Health Check Assessment performed during 18 months of Birth. 
* [NCDHC Health Check Assessment 2 Years view](StructureDefinition-ncdhc-composition-view-hca-2yr.html) - Consolidated view to represent Health Check Assessment performed during 2 years of Birth.
* [NCDHC Health Check Assessment 3 Years view](StructureDefinition-ncdhc-composition-view-hca-3yr.html) - Consolidated view to represent Health Check Assessment performed during 3 years of Birth.
* [NCDHC Health Check Assessment 4 Years view](StructureDefinition-ncdhc-composition-view-hca-4yr.html) - Consolidated view to represent Health Check Assessment performed during 4 years of Birth.  

## Digital Pregnancy Health Record Profiles  
* [NCDHC Antenatal Record Collection Health Interaction](StructureDefinition-ncdhc-composition-antenatal-record.html) - Composition profile to collect Antenatal Record and associated details