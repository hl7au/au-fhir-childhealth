package http://hl7.org.au/fhir/ch/v1/ImplementationGuide/au-ch;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class NCDHCEstimatedGestationObservationProfile {

}
