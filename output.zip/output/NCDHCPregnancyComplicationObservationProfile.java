package http://hl7.org.au/fhir/ch/ImplementationGuide/au-ch;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class NCDHCPregnancyComplicationObservationProfile {

}
