TODO: Add more details here once the Capability Statement and OAI is decided
